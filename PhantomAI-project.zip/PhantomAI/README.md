# PHANTOM AI (Android)

Voice-first Android assistant: Kotlin, Jetpack Compose, Room, DataStore, SpeechRecognizer, TextToSpeech.
Claude runs behind **your own backend**, so no Anthropic key is ever in the app.

> **Build status:** this source has NOT been compiled or run by its author (no Android SDK or network was available).
> Expect to fix a few small compile errors on the first build. The GitHub Actions log will show them.

## Architecture
```
Phone (Compose UI + VoiceController)
   -> POST /v1/chat  (Bearer APP_TOKEN)        backend/server.js
         -> Claude Messages API with tool definitions (holds ANTHROPIC_API_KEY)
   <- { text, actions:[{name,args}] }          requests only, nothing executed server-side
ActionParser (allowlist + range validation) -> confirmation/countdown (risky ones) -> ActionEngine (public Android APIs) -> honest result -> action log + spoken reply
```
The model can only name actions in `ActionType`. Unknown names, bad ranges, or unknown settings pages are rejected before anything runs.

## 1. Run the backend
```
cd backend && npm install
export ANTHROPIC_API_KEY=sk-ant-...      # your key, server side only
export APP_TOKEN=$(openssl rand -hex 32)  # shared secret between app and backend
npm start
```
Deploy anywhere that runs Node 18+ (Render, Fly.io, Railway, a VPS). Use HTTPS. The phone must reach it.
`MODEL` defaults to `claude-sonnet-5-5`; change it via env var if needed.

## 2. Build PhantomAI.apk
**Option A: GitHub Actions (no local setup)**
1. Create a GitHub repo and push this folder (the `.github` folder must be included).
2. Actions tab -> "Build PhantomAI.apk" -> Run workflow (it also runs on push).
3. Open the finished run -> Artifacts -> `PhantomAI-apk` -> unzip -> `PhantomAI.apk`.

**Option B: Android Studio**
1. File -> Open this folder; let Gradle sync (if asked, use Gradle 8.9 and JDK 17).
2. Build -> Build APK(s). Output: `app/build/outputs/apk/debug/app-debug.apk` (rename to PhantomAI.apk).

**Option C: command line** (needs JDK 17, Android SDK 35, Gradle 8.9): `gradle :app:assembleDebug`

## 3. Install and set up
1. Copy the APK to your phone, open it, allow "install unknown apps" for your file manager/browser.
2. Open Phantom -> menu -> **API connection**: enter backend URL and APP_TOKEN -> Save -> Test.
3. Menu -> **Device permissions**: grant only what you want (see table).
4. Tap the mic and try: "what's my battery", "turn on the flashlight", "open YouTube", "set an alarm for 7 AM".

## What works directly (no extra access)
| Feature | Notes |
|---|---|
| Voice input, TTS replies, text fallback | Needs mic permission (runtime). Recognizer may need internet on some phones. |
| Claude conversation + memory across restarts | Room database, reviewable/deletable. |
| Open installed apps | Verified only that Android accepted the launch. |
| Flashlight | Verified via torch callback. |
| Battery status | Read-only. |
| Media volume | Read back and verified. |
| Open system settings pages | Wi-Fi, Bluetooth, display, sound, battery, etc. Claude then guides you through the taps. |
| Alarms and timers | Handed to your Clock app. Android gives no confirmation back, and the app says so. |
| Media keys (play/pause/next/prev) | Sent to the active player; no confirmation available. |
| Stop commands, emergency stop, action log | Always on. |

## What needs additional system access (you grant it)
| Feature | Access required |
|---|---|
| Screen brightness | "Modify system settings" (special access) |
| Do Not Disturb | "Do Not Disturb access" |
| Read notifications aloud | Notification access |
| Turn off screen / lock | Phantom accessibility service (global Lock Screen only) **or** device admin (force-lock only) |
| Open power menu | Phantom accessibility service |

## What is NOT possible / not implemented
- **Powering the phone off.** Ordinary apps cannot do it (needs a system-signed or device-owner app). Phantom opens the power menu or tells you to hold the power button, and never claims it shut down.
- **Sending messages, purchases, typing in other apps:** no such action exists. "Help me write a message" drafts text for you to paste.
- **Always-on background wake word:** not implemented (unreliable and battery-hungry with SpeechRecognizer). Wake word works only while the app is open with the screen kept on, and many phones play a system beep on each restart.
- **Reminders:** implemented as alarms with a label, not calendar reminders.
- "Say stop while I'm speaking" is experimental (own voice can trigger it; use headphones); the Stop button always works.
- Silence length is passed to the recognizer as a hint; some recognizers ignore it.
- Release hardening (R8, signing, Play policy review of the accessibility declaration) is not done. Debug build only.

## Safety design
- Lock screen, power menu and Do Not Disturb require your explicit confirmation (button or "yes"), then a configurable countdown (default 3 s) that you can cancel.
- Spoken results come from the phone's verified outcome, not from the model's wording.
- Notification text is treated as untrusted data (prompt-injection safeguard).
- No arbitrary code/shell execution; no root; accessibility service declares no content access.
- Memories refuse passwords, 6-digit codes and card numbers; optional AES-GCM encryption via Android Keystore.
