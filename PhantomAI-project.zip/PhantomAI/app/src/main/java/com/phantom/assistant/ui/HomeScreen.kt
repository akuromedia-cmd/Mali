@file:OptIn(ExperimentalMaterial3Api::class)

package com.phantom.assistant.ui

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.phantom.assistant.PhantomViewModel
import com.phantom.assistant.Phase

enum class Screen { HOME, HISTORY, PERMISSIONS, VOICE, MEMORY, API, ACTIONS, PRIVACY }

@Composable
fun PhantomRoot(vm: PhantomViewModel) {
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    BackHandler(enabled = screen != Screen.HOME) { screen = Screen.HOME }
    Surface(Modifier.fillMaxSize(), color = Bg, contentColor = TextHi) {
        val back = { screen = Screen.HOME }
        when (screen) {
            Screen.HOME -> HomeScreen(vm) { screen = it }
            Screen.HISTORY -> HistoryScreen(vm, back)
            Screen.PERMISSIONS -> PermissionsScreen(back)
            Screen.VOICE -> VoiceSettingsScreen(vm, back)
            Screen.MEMORY -> MemoryScreen(vm, back)
            Screen.API -> ApiScreen(vm, back)
            Screen.ACTIONS -> ActionLogScreen(vm, back)
            Screen.PRIVACY -> PrivacyScreen(vm, back)
        }
    }
}

@Composable
fun Orb(phase: Phase, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "orb")
    val fast = phase == Phase.LISTENING
    val busy = phase == Phase.THINKING || phase == Phase.EXECUTING
    val pulse by t.animateFloat(
        0.93f, 1.07f,
        infiniteRepeatable(tween(if (fast) 650 else 1900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse",
    )
    val spin by t.animateFloat(
        0f, 360f,
        infiniteRepeatable(tween(if (busy) 1400 else 10000, easing = LinearEasing)),
        label = "spin",
    )
    val core = when (phase) {
        Phase.LISTENING -> Cyan
        Phase.SPEAKING -> Purple
        Phase.THINKING, Phase.EXECUTING -> Color(0xFFB794F6)
        Phase.IDLE -> Color(0xFF6D4AD6)
    }
    Canvas(modifier.size(210.dp).semantics { contentDescription = "Phantom is ${phase.name.lowercase()}" }) {
        val c = center
        val half = size.minDimension / 2
        drawCircle(Brush.radialGradient(listOf(core.copy(alpha = 0.32f), Color.Transparent), c, half), radius = half * pulse, center = c)
        val r = half * 0.58f * (if (phase == Phase.SPEAKING) pulse else 1f)
        drawCircle(Brush.radialGradient(listOf(Cyan.copy(alpha = 0.9f), core, Color(0xFF241552)), c, r * 1.2f), radius = r, center = c)
        rotate(spin, c) {
            val d = r * 2.5f
            drawArc(Cyan, 0f, 80f, false, Offset(c.x - d / 2, c.y - d / 2), Size(d, d), style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
            drawArc(Purple, 180f, 60f, false, Offset(c.x - d / 2, c.y - d / 2), Size(d, d), style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
        }
    }
}

@Composable
private fun rememberBattery(): State<Pair<Int, Boolean>> {
    val ctx = LocalContext.current
    val st = remember { mutableStateOf(0 to false) }
    DisposableEffect(Unit) {
        fun read(i: Intent?) {
            if (i == null) return
            val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            st.value = (l * 100 / s.coerceAtLeast(1)) to
                (status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL)
        }
        val r = object : BroadcastReceiver() { override fun onReceive(c: Context, i: Intent) = read(i) }
        read(ContextCompat.registerReceiver(ctx, r, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED))
        onDispose { ctx.unregisterReceiver(r) }
    }
    return st
}

@Composable
fun HomeScreen(vm: PhantomViewModel, nav: (Screen) -> Unit) {
    val ui by vm.state.collectAsStateWithLifecycle()
    val msgs by vm.messages.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    val view = LocalView.current
    val battery by rememberBattery()
    var menu by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var showApps by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }

    val keepOn = ui.continuous || ui.wake
    DisposableEffect(keepOn) { view.keepScreenOn = keepOn; onDispose { view.keepScreenOn = false } }

    var afterGrant by remember { mutableStateOf<(() -> Unit)?>(null) }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) afterGrant?.invoke() else vm.showError("Microphone permission denied. You can still type commands.")
        afterGrant = null
    }
    fun ensureMic(block: () -> Unit) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) block()
        else { afterGrant = block; micLauncher.launch(Manifest.permission.RECORD_AUDIO) }
    }

    val busy = ui.phase != Phase.IDLE
    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(horizontal = 16.dp)) {
        // ---- top bar ----
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("PHANTOM", fontSize = 18.sp, fontWeight = FontWeight.Bold, letterSpacing = 5.sp, color = Cyan)
            Spacer(Modifier.weight(1f))
            Text(
                "${if (battery.second) "⚡" else ""}${battery.first}%",
                color = TextLo, fontSize = 13.sp,
                modifier = Modifier.semantics { contentDescription = "Battery ${battery.first} percent" },
            )
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier.size(9.dp).clip(CircleShape)
                    .background(when (ui.connected) { true -> Good; false -> Danger; null -> TextLo })
                    .semantics { contentDescription = when (ui.connected) { true -> "Backend connected"; false -> "Backend unreachable"; null -> "Backend not configured" } },
            )
            IconButton({ showHistory = true }) { Icon(Icons.Rounded.History, "Conversation history") }
            Box {
                IconButton({ menu = true }) { Icon(Icons.Rounded.MoreVert, "Menu") }
                DropdownMenu(menu, { menu = false }) {
                    listOf(
                        "Chat history" to Screen.HISTORY, "Device permissions" to Screen.PERMISSIONS,
                        "Voice settings" to Screen.VOICE, "Memory" to Screen.MEMORY,
                        "API connection" to Screen.API, "Action history" to Screen.ACTIONS, "Privacy" to Screen.PRIVACY,
                    ).forEach { (label, s) -> DropdownMenuItem(text = { Text(label) }, onClick = { menu = false; nav(s) }) }
                }
            }
        }

        // ---- orb + text ----
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(8.dp))
            Orb(ui.phase)
            Text(
                when (ui.phase) {
                    Phase.IDLE -> if (ui.wake) "Say \"Hey Phantom\"" else "Tap the mic to talk"
                    Phase.LISTENING -> "Listening…"
                    Phase.THINKING -> "Thinking…"
                    Phase.SPEAKING -> "Speaking…"
                    Phase.EXECUTING -> "Executing…"
                },
                color = TextLo, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp),
            )
            if (ui.partial.isNotBlank())
                Text("“${ui.partial}”", color = Cyan, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 12.dp))
            if (ui.reply.isNotBlank())
                Text(ui.reply, textAlign = TextAlign.Start, fontSize = 16.sp, modifier = Modifier.padding(top = 12.dp).fillMaxWidth())
            ui.error?.let { Text(it, color = Danger, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 12.dp)) }

            ui.pending?.let { pending ->
                Card(
                    Modifier.fillMaxWidth().padding(top = 14.dp),
                    colors = CardDefaults.cardColors(containerColor = PanelHi),
                ) {
                    Column(Modifier.padding(14.dp)) {
                        Text(pending, fontWeight = FontWeight.SemiBold)
                        if (ui.countdown > 0) Text("Running in ${ui.countdown}…", color = Cyan, modifier = Modifier.padding(top = 4.dp))
                        else Text("Say \"yes\" or tap Confirm.", color = TextLo, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                        Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            if (ui.countdown <= 0) Button({ vm.confirmPending() }) { Text("Confirm") }
                            OutlinedButton({ vm.cancelPending() }) { Text("Cancel") }
                        }
                    }
                }
            }
        }

        // ---- quick actions ----
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            QuickChip(Icons.Rounded.FlashlightOn, "Flashlight") { vm.quickFlashlight() }
            QuickChip(Icons.Rounded.Alarm, "Alarms") { vm.quickAlarms() }
            QuickChip(Icons.Rounded.Apps, "Apps") { showApps = true }
            QuickChip(Icons.Rounded.Settings, "Settings") { vm.quickSettings() }
        }

        // ---- controls ----
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            FilterChip(ui.continuous, { ensureMic { vm.toggleContinuous(!ui.continuous) } }, { Text("Continuous") })
            Box(
                Modifier.size(78.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Purple, Cyan)))
                    .clickable(onClickLabel = "Microphone") { ensureMic { vm.onMic() } }
                    .semantics { contentDescription = "Microphone" },
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.Mic, null, tint = Color.White, modifier = Modifier.size(36.dp)) }
            FilterChip(ui.wake, { ensureMic { vm.toggleWake(!ui.wake) } }, { Text("Wake word") })
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            if (ui.phase == Phase.SPEAKING) TextButton({ vm.stopSpeakingOnly() }) { Text("Stop speaking") }
            if (busy || ui.continuous || ui.wake)
                Button({ vm.emergencyStop() }, colors = ButtonDefaults.buttonColors(containerColor = Danger)) {
                    Icon(Icons.Rounded.Stop, null); Spacer(Modifier.width(6.dp)); Text("Emergency stop")
                }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                text, { text = it }, Modifier.weight(1f), singleLine = true,
                placeholder = { Text("Or type a command…") },
            )
            IconButton({ vm.submit(text); text = "" }, enabled = text.isNotBlank()) {
                Icon(Icons.AutoMirrored.Rounded.Send, "Send", tint = Cyan)
            }
        }
    }

    if (showHistory) ModalBottomSheet({ showHistory = false }, containerColor = Panel) {
        Text("Conversation", fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp))
        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 480.dp).padding(16.dp), reverseLayout = true, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs.reversed(), key = { it.id }) { Bubble(it.role, it.text) }
        }
    }

    if (showApps) {
        val apps = remember { vm.listApps() }
        AlertDialog(
            onDismissRequest = { showApps = false },
            confirmButton = { TextButton({ showApps = false }) { Text("Close") } },
            title = { Text("Open an app") },
            text = {
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    items(apps, key = { it.pkg }) { a ->
                        Text(a.label, Modifier.fillMaxWidth().clickable { showApps = false; vm.launchApp(a) }.padding(vertical = 12.dp))
                    }
                }
            },
        )
    }
}

@Composable
fun Bubble(role: String, text: String) {
    val mine = role == "user"
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Text(
            text,
            Modifier.widthIn(max = 300.dp).clip(RoundedCornerShape(14.dp))
                .background(if (mine) Purple.copy(alpha = 0.35f) else PanelHi).padding(10.dp),
            fontSize = 15.sp,
        )
    }
}

@Composable
private fun QuickChip(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClickLabel = label, onClick = onClick).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, null, tint = Cyan)
        Text(label, fontSize = 11.sp, color = TextLo)
    }
}
