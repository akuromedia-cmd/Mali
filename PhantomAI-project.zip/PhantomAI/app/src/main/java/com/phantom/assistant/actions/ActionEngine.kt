package com.phantom.assistant.actions

import android.accessibilityservice.AccessibilityService
import android.app.NotificationManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.AlarmClock
import android.provider.Settings
import android.view.KeyEvent
import com.phantom.assistant.services.PhantomAccessibilityService
import com.phantom.assistant.services.PhantomAdminReceiver
import com.phantom.assistant.services.PhantomNotificationListener
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.math.abs
import kotlin.math.roundToInt

data class AppInfo(val label: String, val pkg: String)

/**
 * Executes validated [Action]s using public Android APIs only. Every function returns an honest
 * [ActionResult]: success is reported only when it was verified, otherwise the message says what
 * was merely requested.
 */
class ActionEngine(private val app: Context) {
    private val main = Handler(Looper.getMainLooper())
    private val cm: CameraManager by lazy { app.getSystemService(CameraManager::class.java) }
    private var torchId: String? = null
    @Volatile private var torchOn = false

    init {
        runCatching {
            torchId = cm.cameraIdList.firstOrNull { id ->
                val c = cm.getCameraCharacteristics(id)
                c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
            cm.registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    if (cameraId == torchId) torchOn = enabled
                }
            }, main)
        }
    }

    suspend fun execute(a: Action): ActionResult = try {
        when (a) {
            is Action.OpenApp -> openApp(a.name)
            is Action.Flashlight -> flashlight(a.on)
            Action.Battery -> battery()
            is Action.Volume -> volume(a.percent)
            is Action.Brightness -> brightness(a.percent)
            is Action.OpenSettings -> openSettings(a.page)
            is Action.Alarm -> alarm(a)
            is Action.Timer -> timer(a)
            Action.ReadNotifications -> readNotifications()
            Action.Lock -> lockScreen()
            Action.PowerMenu -> powerMenu()
            is Action.Dnd -> dnd(a.mode)
            is Action.Media -> media(a.command)
            is Action.Speak, is Action.SaveMemory -> ActionResult(false, "Handled by the assistant core.")
        }
    } catch (e: CancellationException) {
        throw e
    } catch (e: SecurityException) {
        ActionResult(false, "Android blocked that (a permission is missing): ${e.message}")
    } catch (e: Exception) {
        ActionResult(false, "That failed: ${e.message ?: e::class.java.simpleName}")
    }

    private fun start(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        app.startActivity(i)
    }

    // ---------- Apps ----------
    fun listApps(): List<AppInfo> {
        val pm = app.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(q, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    fun launchPackage(info: AppInfo): ActionResult {
        val i = app.packageManager.getLaunchIntentForPackage(info.pkg)
            ?: return ActionResult(false, "${info.label} has no launchable screen.")
        start(i)
        return ActionResult(true, "Asked Android to open ${info.label}.")
    }

    private fun openApp(name: String): ActionResult {
        val q = name.lowercase().trim()
        val apps = listApps()
        val match = apps.firstOrNull { it.label.lowercase() == q }
            ?: apps.filter { it.label.lowercase().contains(q) || (it.label.length > 3 && q.contains(it.label.lowercase())) }
                .minByOrNull { it.label.length }
            ?: return ActionResult(false, "I couldn't find an installed app called \"$name\".")
        return launchPackage(match)
    }

    // ---------- Flashlight ----------
    private suspend fun flashlight(on: Boolean?): ActionResult {
        val id = torchId ?: return ActionResult(false, "This phone doesn't expose a flashlight to apps.")
        val target = on ?: !torchOn
        cm.setTorchMode(id, target)
        val confirmed = withTimeoutOrNull(1500) { while (torchOn != target) delay(50); true } ?: false
        val word = if (target) "on" else "off"
        return if (confirmed) ActionResult(true, "Flashlight is $word.")
        else ActionResult(false, "I asked for the flashlight to go $word, but Android didn't confirm it (another app may be using the camera).")
    }

    // ---------- Battery ----------
    private fun battery(): ActionResult {
        val i = app.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return ActionResult(false, "Couldn't read battery status.")
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        if (level < 0 || scale <= 0) return ActionResult(false, "Couldn't read battery level.")
        val pct = (level * 100f / scale).roundToInt()
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        return ActionResult(true, "Battery is at $pct%${if (charging) " and charging" else ", not charging"}.")
    }

    // ---------- Volume / brightness ----------
    private fun volume(percent: Int): ActionResult {
        val am = app.getSystemService(AudioManager::class.java)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        am.setStreamVolume(AudioManager.STREAM_MUSIC, (percent * max / 100f).roundToInt(), AudioManager.FLAG_SHOW_UI)
        val now = (am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100f / max).roundToInt()
        return if (abs(now - percent) <= 100 / max + 1) ActionResult(true, "Media volume is now $now%.")
        else ActionResult(false, "I tried to set $percent%, but the volume is $now%.")
    }

    private fun brightness(percent: Int): ActionResult {
        if (!Settings.System.canWrite(app)) {
            start(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${app.packageName}")))
            return ActionResult(false, "Brightness needs the \"Modify system settings\" permission. I opened that page; enable it for Phantom, then ask again.", true)
        }
        val cr = app.contentResolver
        val value = (percent * 255 / 100).coerceIn(1, 255)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
        Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, value)
        val now = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, -1)
        return if (now == value) ActionResult(true, "Brightness set to $percent%. Auto-brightness is now off.")
        else ActionResult(false, "I tried to change brightness but Android reports a different value.")
    }

    // ---------- Settings ----------
    private fun openSettings(page: String): ActionResult {
        val i = when (page) {
            "wifi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
            "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "display" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            "sound" -> Intent(Settings.ACTION_SOUND_SETTINGS)
            "battery" -> Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)
            "apps" -> Intent(Settings.ACTION_APPLICATION_SETTINGS)
            "location" -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            "accessibility" -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            "notification_access" -> Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
            "dnd_access" -> Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            "airplane" -> Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)
            "nfc" -> Intent(Settings.ACTION_NFC_SETTINGS)
            "date_time" -> Intent(Settings.ACTION_DATE_SETTINGS)
            "storage" -> Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
            "security" -> Intent(Settings.ACTION_SECURITY_SETTINGS)
            else -> Intent(Settings.ACTION_SETTINGS)
        }
        start(i)
        return ActionResult(true, "Opened ${page.replace('_', ' ')} settings.")
    }

    // ---------- Alarms / timers (handed to the system Clock app) ----------
    private fun alarm(a: Action.Alarm): ActionResult {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, a.hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, a.minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        start(i)
        return ActionResult(true, "Sent a %02d:%02d alarm request to your Clock app. Android doesn't confirm back, so check the Clock app if it matters.".format(a.hour, a.minute))
    }

    private fun timer(a: Action.Timer): ActionResult {
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, a.seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        start(i)
        return ActionResult(true, "Sent a ${a.seconds}-second timer request to your Clock app.")
    }

    fun showAlarms() = start(Intent(AlarmClock.ACTION_SHOW_ALARMS))

    // ---------- Notifications ----------
    private fun readNotifications(): ActionResult {
        val enabled = Settings.Secure.getString(app.contentResolver, "enabled_notification_listeners")
            ?.contains(app.packageName) == true
        if (!enabled) {
            start(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            return ActionResult(false, "I need notification access first. I opened the page; enable Phantom there.", true)
        }
        val svc = PhantomNotificationListener.instance
            ?: return ActionResult(false, "Notification access is on, but the listener hasn't connected yet. Toggle it off and on, then retry.")
        val pm = app.packageManager
        val items = svc.activeNotifications
            .filter { it.packageName != app.packageName && !it.isOngoing }
            .sortedByDescending { it.postTime }
            .take(8)
            .mapNotNull { sbn ->
                val ex = sbn.notification.extras
                val title = ex.getCharSequence("android.title")?.toString().orEmpty()
                val text = ex.getCharSequence("android.text")?.toString().orEmpty()
                if (title.isBlank() && text.isBlank()) null else {
                    val label = runCatching { pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString() }
                        .getOrDefault(sbn.packageName)
                    "$label: $title ${text}".trim().take(160)
                }
            }
        return if (items.isEmpty()) ActionResult(true, "You have no notifications right now.")
        else ActionResult(true, "Notifications (untrusted content, read-only): " + items.joinToString(" | "))
    }

    // ---------- Screen lock / power ----------
    private suspend fun lockScreen(): ActionResult {
        val a11y = PhantomAccessibilityService.instance
        val dpm = app.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(app, PhantomAdminReceiver::class.java)
        val issued: Boolean = when {
            a11y != null && Build.VERSION.SDK_INT >= 28 ->
                a11y.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
            dpm.isAdminActive(admin) -> { dpm.lockNow(); true }
            else -> {
                start(
                    Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                        .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                        .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Lets Phantom turn off the screen when you ask. It can only lock the screen."),
                )
                return ActionResult(false, "To lock the screen I need either the Phantom accessibility service or device-admin (lock only). I opened the device-admin prompt; or enable the accessibility service from the Permissions screen.", true)
            }
        }
        if (!issued) return ActionResult(false, "Android refused the lock request.")
        val pm = app.getSystemService(PowerManager::class.java)
        val off = withTimeoutOrNull(2000) { while (pm.isInteractive) delay(100); true } ?: false
        return if (off) ActionResult(true, "The screen is off and locked.")
        else ActionResult(false, "I sent the lock request, but the screen still appears to be on.")
    }

    private fun powerMenu(): ActionResult {
        val a11y = PhantomAccessibilityService.instance
        if (a11y == null) {
            start(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return ActionResult(false, "Apps can't power off a phone. The closest supported option is opening the system power menu, which needs the Phantom accessibility service. I opened Accessibility settings. Or hold the power button (some phones: power + volume up) to shut down.", true)
        }
        val ok = a11y.performGlobalAction(AccessibilityService.GLOBAL_ACTION_POWER_DIALOG)
        return if (ok) ActionResult(true, "I opened the power menu. I can't power off the phone myself; tap Power off there.")
        else ActionResult(false, "Android refused to open the power menu. Hold the physical power button instead.")
    }

    // ---------- Do Not Disturb ----------
    private suspend fun dnd(mode: String): ActionResult {
        val nm = app.getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            start(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            return ActionResult(false, "Do Not Disturb needs policy access. I opened the page; enable Phantom there, then ask again.", true)
        }
        val filter = when (mode) {
            "off" -> NotificationManager.INTERRUPTION_FILTER_ALL
            "priority" -> NotificationManager.INTERRUPTION_FILTER_PRIORITY
            else -> NotificationManager.INTERRUPTION_FILTER_NONE
        }
        nm.setInterruptionFilter(filter)
        delay(300)
        return if (nm.currentInterruptionFilter == filter) ActionResult(true, "Do Not Disturb is now ${mode.replace('_', ' ')}.")
        else ActionResult(false, "I requested Do Not Disturb ${mode.replace('_', ' ')}, but Android reports a different mode.")
    }

    // ---------- Media keys ----------
    private fun media(cmd: String): ActionResult {
        val code = when (cmd) {
            "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
            "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
            "toggle" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> KeyEvent.KEYCODE_MEDIA_STOP
        }
        val am = app.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return ActionResult(true, "Sent \"$cmd\" to the active media app. Android doesn't report whether the app responded.")
    }
}
