package com.phantom.assistant

import android.app.Application
import com.phantom.assistant.data.PhantomDb
import com.phantom.assistant.data.SettingsRepo

class PhantomApp : Application() {
    val db by lazy { PhantomDb.get(this) }
    val settings by lazy { SettingsRepo(this) }
}
