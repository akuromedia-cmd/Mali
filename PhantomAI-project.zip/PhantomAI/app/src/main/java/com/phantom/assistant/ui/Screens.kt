package com.phantom.assistant.ui

import android.Manifest
import android.app.NotificationManager
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings as AndroidSettings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.phantom.assistant.PhantomViewModel
import com.phantom.assistant.services.PhantomAccessibilityService
import com.phantom.assistant.services.PhantomAdminReceiver
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun fmt(ts: Long) = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(ts))

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScreenFrame(
    title: String,
    onBack: () -> Unit,
    scroll: Boolean = true,
    actions: @Composable RowScope.() -> Unit = {},
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") }
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            actions()
        }
        val m = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp)
        Column(if (scroll) m.verticalScroll(rememberScrollState()) else m, content = content)
    }
}

@Composable
private fun rememberResumeTick(): Int {
    val owner = LocalLifecycleOwner.current
    var tick by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }
    return tick
}

// ---------------- History ----------------
@Composable
fun HistoryScreen(vm: PhantomViewModel, back: () -> Unit) {
    val msgs by vm.messages.collectAsStateWithLifecycle()
    ScreenFrame("Chat history", back, scroll = false, actions = {
        TextButton({ vm.clearHistory() }) { Text("Clear all") }
    }) {
        if (msgs.isEmpty()) Text("No conversation yet.", color = TextLo)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), reverseLayout = true) {
            items(msgs.reversed(), key = { it.id }) { m ->
                Column {
                    Text(fmt(m.ts), fontSize = 11.sp, color = TextLo)
                    Bubble(m.role, m.text)
                }
            }
        }
    }
}

// ---------------- Permissions ----------------
private data class PermRow(val title: String, val why: String, val granted: Boolean, val button: String, val onGrant: () -> Unit)

@Composable
fun PermissionsScreen(back: () -> Unit) {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun open(i: Intent) = ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))

    val rows = remember(tick) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val dpm = ctx.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(ctx, PhantomAdminReceiver::class.java)
        val listeners = AndroidSettings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners").orEmpty()
        listOf(
            PermRow("Microphone", "Voice commands. Audio is processed by your phone's speech recognizer, only while the listening indicator is showing.",
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED,
                "Allow") { micLauncher.launch(Manifest.permission.RECORD_AUDIO) },
            PermRow("Alarms and timers", "Granted automatically at install. Requests are handed to your Clock app.", true, "") {},
            PermRow("Notification access", "Needed only to read your current notifications aloud when you ask.",
                listeners.contains(ctx.packageName), "Open settings") { open(Intent(AndroidSettings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
            PermRow("Do Not Disturb access", "Needed to switch Do Not Disturb on or off.",
                nm.isNotificationPolicyAccessGranted, "Open settings") { open(Intent(AndroidSettings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)) },
            PermRow("Modify system settings", "Needed to change screen brightness.",
                AndroidSettings.System.canWrite(ctx), "Open settings") {
                open(Intent(AndroidSettings.ACTION_MANAGE_WRITE_SETTINGS, android.net.Uri.parse("package:${ctx.packageName}")))
            },
            PermRow("Accessibility service (screen and power)", "Lets Phantom press Lock Screen and open the Power Menu. It declares no screen-reading ability.",
                PhantomAccessibilityService.instance != null, "Open settings") { open(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS)) },
            PermRow("Device admin (lock only)", "Alternative to accessibility for turning off the screen. Grants the force-lock policy only.",
                dpm.isAdminActive(admin), "Enable") {
                open(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Lets Phantom turn off the screen when you ask."))
            },
        )
    }
    ScreenFrame("Device permissions", back) {
        Text("Phantom asks for nothing until you tap a button here. Each one can be revoked in Android settings at any time.", color = TextLo, fontSize = 13.sp)
        rows.forEach { r ->
            Card(Modifier.fillMaxWidth().padding(top = 10.dp), colors = CardDefaults.cardColors(containerColor = PanelHi)) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (r.granted) Icons.Rounded.CheckCircle else Icons.Rounded.ErrorOutline, null, tint = if (r.granted) Good else TextLo)
                        Spacer(Modifier.width(8.dp))
                        Text(r.title, fontWeight = FontWeight.SemiBold)
                    }
                    Text(r.why, fontSize = 13.sp, color = TextLo, modifier = Modifier.padding(top = 4.dp))
                    if (!r.granted && r.button.isNotEmpty())
                        Button(r.onGrant, Modifier.padding(top = 8.dp)) { Text(r.button) }
                }
            }
        }
    }
}

// ---------------- Voice settings ----------------
@Composable
private fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, steps: Int, show: (Float) -> String, onDone: (Float) -> Unit) {
    var v by remember(value) { mutableFloatStateOf(value) }
    Column(Modifier.padding(top = 12.dp)) {
        Text("$label: ${show(v)}")
        Slider(v, { v = it }, valueRange = range, steps = steps, onValueChangeFinished = { onDone(v) })
    }
}

@Composable
private fun SwitchRow(label: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(label); if (sub.isNotEmpty()) Text(sub, fontSize = 12.sp, color = TextLo) }
        Switch(checked, onChange)
    }
}

@Composable
fun VoiceSettingsScreen(vm: PhantomViewModel, back: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    ScreenFrame("Voice settings", back) {
        LabeledSlider("Silence before I stop listening", s.silenceMs / 1000f, 1f..4f, 5, { "%.1f s".format(it) }) { v -> vm.updateSettings { it.copy(silenceMs = (v * 1000).toInt()) } }
        Text("Best effort: some speech recognizers ignore this value.", fontSize = 12.sp, color = TextLo)
        LabeledSlider("Countdown before confirmed actions", s.countdownSec.toFloat(), 0f..10f, 9, { "${it.toInt()} s" }) { v -> vm.updateSettings { it.copy(countdownSec = v.toInt()) } }
        LabeledSlider("Speech rate", s.speechRate, 0.6f..1.6f, 9, { "%.1fx".format(it) }) { v -> vm.updateSettings { it.copy(speechRate = v) } }
        SwitchRow("Speak replies", "", s.speakReplies) { c -> vm.updateSettings { it.copy(speakReplies = c) } }
        SwitchRow("Sound feedback", "Beeps for listening, success and failure", s.sounds) { c -> vm.updateSettings { it.copy(sounds = c) } }
        SwitchRow("Say \"stop\" while I'm speaking", "Experimental. Use headphones, otherwise my own voice can trigger it.", s.bargeIn) { c -> vm.updateSettings { it.copy(bargeIn = c) } }
    }
}

// ---------------- Memory ----------------
@Composable
fun MemoryScreen(vm: PhantomViewModel, back: () -> Unit) {
    val items by vm.memories.collectAsStateWithLifecycle()
    val s by vm.settings.collectAsStateWithLifecycle()
    var note by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    ScreenFrame("Memory", back, scroll = false, actions = { TextButton({ vm.clearMemories() }) { Text("Clear all") } }) {
        SwitchRow("Encrypt new memories", "AES-256, key kept in the Android Keystore", s.encryptMemories) { c -> vm.updateSettings { it.copy(encryptMemories = c) } }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(note, { note = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("Add something to remember") })
            TextButton({ vm.addMemory(note) { msg = it }; note = "" }, enabled = note.isNotBlank()) { Text("Add") }
        }
        if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp, color = TextLo)
        Text("Phantom refuses to store passwords, codes or card numbers.", fontSize = 12.sp, color = TextLo, modifier = Modifier.padding(vertical = 6.dp))
        if (items.isEmpty()) Text("Nothing remembered yet.", color = TextLo)
        LazyColumn {
            items(items, key = { it.id }) { m ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(m.text)
                        Text("${m.kind} · ${fmt(m.ts)}${if (m.encrypted) " · encrypted" else ""}", fontSize = 11.sp, color = TextLo)
                    }
                    IconButton({ vm.forget(m.id) }) { Icon(Icons.Rounded.Delete, "Delete memory") }
                }
            }
        }
    }
}

// ---------------- API ----------------
@Composable
fun ApiScreen(vm: PhantomViewModel, back: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    var url by remember(s.backendUrl) { mutableStateOf(s.backendUrl) }
    var token by remember(s.appToken) { mutableStateOf(s.appToken) }
    var result by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    ScreenFrame("API connection", back) {
        Text("Phantom talks to your own backend, which holds the Claude API key. No Anthropic key is ever stored on this phone.", color = TextLo, fontSize = 13.sp)
        OutlinedTextField(url, { url = it }, Modifier.fillMaxWidth().padding(top = 12.dp), singleLine = true, label = { Text("Backend URL (https://…)") })
        OutlinedTextField(token, { token = it }, Modifier.fillMaxWidth().padding(top = 8.dp), singleLine = true,
            label = { Text("App token") }, visualTransformation = PasswordVisualTransformation())
        Text("The app token is the APP_TOKEN you set on the backend. It is stored encrypted.", fontSize = 12.sp, color = TextLo)
        Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button({ vm.updateSettings { it.copy(backendUrl = url.trim(), appToken = token.trim()) }; vm.checkConnection(); result = "Saved." }) { Text("Save") }
            OutlinedButton({ scope.launch { result = "Testing…"; result = vm.testConnection(url.trim(), token.trim()) } }) { Text("Test") }
        }
        if (result.isNotEmpty()) Text(result, modifier = Modifier.padding(top = 10.dp))
    }
}

// ---------------- Action log ----------------
@Composable
fun ActionLogScreen(vm: PhantomViewModel, back: () -> Unit) {
    val log by vm.actionLog.collectAsStateWithLifecycle()
    ScreenFrame("Action history", back, scroll = false, actions = { TextButton({ vm.clearActionLog() }) { Text("Clear") } }) {
        if (log.isEmpty()) Text("No actions yet.", color = TextLo)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(log, key = { it.id }) { e ->
                Row(verticalAlignment = Alignment.Top) {
                    Icon(if (e.ok) Icons.Rounded.CheckCircle else Icons.Rounded.ErrorOutline, null, tint = if (e.ok) Good else Danger)
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text("${e.type} · ${fmt(e.ts)}", fontSize = 12.sp, color = TextLo)
                        Text(e.message)
                    }
                }
            }
        }
    }
}

// ---------------- Privacy ----------------
@Composable
fun PrivacyScreen(vm: PhantomViewModel, back: () -> Unit) {
    var confirmWipe by remember { mutableStateOf(false) }
    ScreenFrame("Privacy", back) {
        listOf(
            "Your messages, and any memories you've saved, are sent to your own backend and then to the Claude API so I can answer. Nothing else leaves the phone.",
            "Conversation history, memories and the action log live only in a local database on this phone. Android cloud backup is disabled for this app.",
            "Voice is handled by your phone's speech recognizer (it may use Google's service depending on your device). Phantom never records audio itself and listens only while the on-screen indicator shows.",
            "Notification text is read only when you ask, held in memory only, and is not saved. If it is read aloud, the spoken result is saved in your chat history.",
            "Phantom does not store passwords, one-time codes or card numbers, and cannot read other apps' contents.",
        ).forEach { Text("• $it", fontSize = 14.sp, modifier = Modifier.padding(bottom = 10.dp)) }
        OutlinedButton({ vm.clearHistory() }) { Text("Clear conversation history") }
        OutlinedButton({ vm.clearMemories() }, Modifier.padding(top = 8.dp)) { Text("Clear all memories") }
        OutlinedButton({ vm.clearActionLog() }, Modifier.padding(top = 8.dp)) { Text("Clear action history") }
        Button({ confirmWipe = true }, Modifier.padding(top = 8.dp), colors = ButtonDefaults.buttonColors(containerColor = Danger)) { Text("Erase everything") }
    }
    if (confirmWipe) AlertDialog(
        onDismissRequest = { confirmWipe = false },
        title = { Text("Erase everything?") },
        text = { Text("This deletes all chat history, memories and the action log on this phone.") },
        confirmButton = { TextButton({ vm.wipeAll(); confirmWipe = false }) { Text("Erase", color = Danger) } },
        dismissButton = { TextButton({ confirmWipe = false }) { Text("Cancel") } },
    )
}
