package com.phantom.assistant.actions

import org.json.JSONObject

/** The complete allowlist. Anything Claude asks for outside this enum is rejected. */
enum class ActionType {
    OPEN_APP, TOGGLE_FLASHLIGHT, GET_BATTERY_STATUS, SET_MEDIA_VOLUME, SET_SCREEN_BRIGHTNESS,
    OPEN_SYSTEM_SETTINGS, CREATE_ALARM, CREATE_TIMER, START_TIMER, READ_NOTIFICATIONS,
    LOCK_SCREEN, REQUEST_POWER_MENU, SET_DND, MEDIA_CONTROL, SPEAK_TEXT, SAVE_MEMORY,
}

data class ActionResult(val ok: Boolean, val message: String, val needsUserStep: Boolean = false)

sealed interface Action {
    val describe: String
    val needsConfirm: Boolean get() = false

    data class OpenApp(val name: String) : Action { override val describe get() = "Open $name" }
    data class Flashlight(val on: Boolean?) : Action {
        override val describe get() = when (on) { true -> "Turn flashlight on"; false -> "Turn flashlight off"; null -> "Toggle flashlight" }
    }
    data object Battery : Action { override val describe get() = "Check battery" }
    data class Volume(val percent: Int) : Action { override val describe get() = "Set media volume to $percent%" }
    data class Brightness(val percent: Int) : Action { override val describe get() = "Set brightness to $percent%" }
    data class OpenSettings(val page: String) : Action { override val describe get() = "Open $page settings" }
    data class Alarm(val hour: Int, val minute: Int, val label: String) : Action {
        override val describe get() = "Set alarm for %02d:%02d".format(hour, minute)
    }
    data class Timer(val seconds: Int, val label: String) : Action { override val describe get() = "Start a ${seconds}s timer" }
    data object ReadNotifications : Action { override val describe get() = "Read notifications" }
    data object Lock : Action {
        override val describe get() = "Turn off the screen and lock the phone"
        override val needsConfirm get() = true
    }
    data object PowerMenu : Action {
        override val describe get() = "Open the power menu"
        override val needsConfirm get() = true
    }
    data class Dnd(val mode: String) : Action {
        override val describe get() = "Set Do Not Disturb to $mode"
        override val needsConfirm get() = true
    }
    data class Media(val command: String) : Action { override val describe get() = "Media: $command" }
    data class Speak(val text: String) : Action { override val describe get() = "Speak" }
    data class SaveMemory(val kind: String, val content: String) : Action { override val describe get() = "Remember: $content" }
}

object ActionParser {
    val settingsPages = setOf(
        "wifi", "bluetooth", "display", "sound", "battery", "apps", "location", "accessibility",
        "notification_access", "dnd_access", "airplane", "nfc", "date_time", "storage", "security", "main",
    )
    private val mediaCommands = setOf("play", "pause", "toggle", "next", "previous", "stop")
    private val dndModes = setOf("off", "priority", "total_silence")
    private val memoryKinds = setOf("preference", "task", "fact")

    /** Validates a raw model request into a typed [Action], or fails with a readable reason. */
    fun parse(name: String, a: JSONObject): Result<Action> = runCatching<Action> {
        val type = ActionType.entries.firstOrNull { it.name == name } ?: error("Unsupported action: $name")
        when (type) {
            ActionType.OPEN_APP -> Action.OpenApp(a.str("name", 60))
            ActionType.TOGGLE_FLASHLIGHT ->
                Action.Flashlight(if (a.has("on") && !a.isNull("on")) a.getBoolean("on") else null)
            ActionType.GET_BATTERY_STATUS -> Action.Battery
            ActionType.SET_MEDIA_VOLUME -> Action.Volume(a.intIn("percent", 0, 100))
            ActionType.SET_SCREEN_BRIGHTNESS -> Action.Brightness(a.intIn("percent", 1, 100))
            ActionType.OPEN_SYSTEM_SETTINGS -> {
                val p = a.str("page", 30).lowercase()
                require(p in settingsPages) { "Unknown settings page: $p" }
                Action.OpenSettings(p)
            }
            ActionType.CREATE_ALARM ->
                Action.Alarm(a.intIn("hour", 0, 23), a.intIn("minute", 0, 59), a.optString("label", "").take(80))
            ActionType.CREATE_TIMER, ActionType.START_TIMER ->
                Action.Timer(a.intIn("seconds", 1, 86400), a.optString("label", "").take(80))
            ActionType.READ_NOTIFICATIONS -> Action.ReadNotifications
            ActionType.LOCK_SCREEN -> Action.Lock
            ActionType.REQUEST_POWER_MENU -> Action.PowerMenu
            ActionType.SET_DND -> {
                val m = a.str("mode", 20).lowercase()
                require(m in dndModes) { "Unknown DND mode: $m" }
                Action.Dnd(m)
            }
            ActionType.MEDIA_CONTROL -> {
                val c = a.str("command", 20).lowercase()
                require(c in mediaCommands) { "Unknown media command: $c" }
                Action.Media(c)
            }
            ActionType.SPEAK_TEXT -> Action.Speak(a.str("text", 600))
            ActionType.SAVE_MEMORY -> Action.SaveMemory(
                a.optString("kind", "fact").lowercase().takeIf { it in memoryKinds } ?: "fact",
                a.str("content", 300),
            )
        }
    }

    private fun JSONObject.str(k: String, max: Int): String {
        val v = optString(k, "").trim()
        require(v.isNotEmpty()) { "Missing '$k'" }
        require(v.length <= max) { "'$k' is too long" }
        return v
    }

    private fun JSONObject.intIn(k: String, lo: Int, hi: Int): Int {
        require(has(k) && !isNull(k)) { "Missing '$k'" }
        val v = getDouble(k).toInt()
        require(v in lo..hi) { "'$k' must be between $lo and $hi" }
        return v
    }
}
