package com.phantom.assistant.voice

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID

object Sfx {
    enum class Kind { LISTEN, OK, FAIL }

    fun play(k: Kind) {
        runCatching {
            val g = ToneGenerator(AudioManager.STREAM_MUSIC, 55)
            val (tone, ms) = when (k) {
                Kind.LISTEN -> ToneGenerator.TONE_PROP_BEEP to 120
                Kind.OK -> ToneGenerator.TONE_PROP_ACK to 200
                Kind.FAIL -> ToneGenerator.TONE_PROP_NACK to 250
            }
            g.startTone(tone, ms)
            Handler(Looper.getMainLooper()).postDelayed({ g.release() }, ms + 300L)
        }
    }
}

/** Wraps SpeechRecognizer + TextToSpeech. Must be used from the main thread. */
class VoiceController(private val ctx: Context, private val cb: Callbacks) {
    enum class Mode { COMMAND, WAKE, BARGE }

    interface Callbacks {
        fun onPartial(text: String)
        fun onCommand(text: String)
        fun onWake(textAfterWake: String)
        fun onBargeStop()
        fun onError(message: String, fatal: Boolean)
        fun onSpeakDone()
    }

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var mode = Mode.COMMAND
    private var active = false
    private var gen = 0

    var silenceMs = 2000
    var speechRate = 1f

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var currentUtterance: String? = null

    val available: Boolean get() = SpeechRecognizer.isRecognitionAvailable(ctx)

    init {
        tts = TextToSpeech(ctx) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.language = Locale.getDefault()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) = finishSpeak(utteranceId)
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) = finishSpeak(utteranceId)
                    override fun onStop(utteranceId: String?, interrupted: Boolean) = finishSpeak(utteranceId)
                })
            }
        }
    }

    private fun finishSpeak(id: String?) {
        main.post {
            if (id != null && id == currentUtterance) {
                currentUtterance = null
                cb.onSpeakDone()
            }
        }
    }

    // ---------- Text to speech ----------
    fun speak(text: String): Boolean {
        if (!ttsReady) return false
        val id = UUID.randomUUID().toString()
        currentUtterance = id
        tts?.setSpeechRate(speechRate)
        return tts?.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, id) == TextToSpeech.SUCCESS
    }

    fun stopSpeaking() {
        currentUtterance = null
        tts?.stop()
    }

    // ---------- Speech recognition ----------
    fun stopListening() {
        active = false
        gen++
        recognizer?.let { r -> runCatching { r.cancel(); r.destroy() } }
        recognizer = null
    }

    fun listen(m: Mode) {
        stopListening()
        if (!available) {
            cb.onError("Speech recognition isn't available on this phone. You can type instead.", true)
            return
        }
        mode = m
        active = true
        val g = gen
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        recognizer = r
        r.setRecognitionListener(listenerFor(g))
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
            // Best-effort: recognizers may clamp or ignore these.
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, silenceMs.toLong())
            .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, silenceMs.toLong())
        r.startListening(i)
    }

    private fun restart(delayMs: Long = 500) {
        if (!active) return
        val m = mode
        val g = gen
        main.postDelayed({ if (active && g == gen && mode == m) listen(m) }, delayMs)
    }

    private fun text(b: Bundle?): String? =
        b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()

    private fun afterWake(t: String): String? {
        val lower = t.lowercase()
        for (w in listOf("phantom", "fantom")) {
            val idx = lower.indexOf(w)
            if (idx >= 0) return t.substring(idx + w.length).trim().trimStart(',', '.', '!', ' ')
        }
        return null
    }

    private fun isStop(t: String) =
        t.lowercase().split(Regex("\\W+")).any { it == "stop" || it == "quiet" }

    private fun listenerFor(g: Int) = object : RecognitionListener {
        private fun stale() = g != gen
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            if (stale()) return
            val t = text(partialResults) ?: return
            when (mode) {
                Mode.COMMAND -> cb.onPartial(t)
                Mode.BARGE -> if (isStop(t)) { stopListening(); cb.onBargeStop() }
                Mode.WAKE -> {}
            }
        }

        override fun onResults(results: Bundle?) {
            if (stale()) return
            val t = text(results).orEmpty()
            when (mode) {
                Mode.COMMAND ->
                    if (t.isBlank()) cb.onError("I didn't catch that. Tap the mic to retry, or type.", false)
                    else cb.onCommand(t)
                Mode.WAKE -> {
                    val after = afterWake(t)
                    if (after != null) { stopListening(); cb.onWake(after) } else restart()
                }
                Mode.BARGE ->
                    if (isStop(t)) { stopListening(); cb.onBargeStop() } else restart()
            }
        }

        override fun onError(error: Int) {
            if (stale()) return
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                    if (mode == Mode.COMMAND) cb.onError("I didn't hear anything. Tap the mic to retry, or type.", false)
                    else restart()
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                    if (mode == Mode.COMMAND) cb.onError("The recognizer is busy. Try again in a moment.", false)
                    else restart(900)
                SpeechRecognizer.ERROR_CLIENT -> {}
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    stopListening(); cb.onError("Microphone permission is missing.", true)
                }
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> {
                    stopListening(); cb.onError("This phone's speech recognizer needs a network connection right now. You can type instead.", true)
                }
                else -> {
                    stopListening(); cb.onError("Speech recognition failed (code $error). You can type instead.", true)
                }
            }
        }
    }

    fun release() {
        stopListening()
        tts?.stop(); tts?.shutdown(); tts = null
    }
}
