package com.phantom.assistant.services

import android.accessibilityservice.AccessibilityService
import android.app.admin.DeviceAdminReceiver
import android.content.Intent
import android.service.notification.NotificationListenerService
import android.view.accessibility.AccessibilityEvent

/** Only used to read currently-active notifications when you ask. Nothing is stored. */
class PhantomNotificationListener : NotificationListenerService() {
    companion object { @Volatile var instance: PhantomNotificationListener? = null }
    override fun onListenerConnected() { instance = this }
    override fun onListenerDisconnected() { if (instance === this) instance = null }
    override fun onDestroy() { if (instance === this) instance = null; super.onDestroy() }
}

/** Declares no content access; exists only to perform global Lock Screen / Power Menu actions. */
class PhantomAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: PhantomAccessibilityService? = null }
    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
}

/** force-lock policy only. */
class PhantomAdminReceiver : DeviceAdminReceiver()
