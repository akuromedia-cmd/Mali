package com.phantom.assistant.net

import com.phantom.assistant.data.Settings
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class ChatTurn(val role: String, val text: String)
data class ActionRequest(val id: String, val name: String, val args: JSONObject)
data class AssistantReply(val text: String, val actions: List<ActionRequest>)

/**
 * Talks ONLY to your own backend (which holds the Claude API key).
 * The app never contains or sends an Anthropic key.
 */
class BackendClient {
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    private fun base(s: Settings): String {
        val u = s.backendUrl.trim().trimEnd('/')
        if (u.isEmpty()) throw IOException("Set your backend URL in API connection settings first.")
        return u
    }

    private suspend fun Call.await(): Response = suspendCancellableCoroutine { c ->
        c.invokeOnCancellation { cancel() }
        enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (c.isActive) c.resumeWithException(e)
            }
            override fun onResponse(call: Call, response: Response) {
                c.resume(response)
            }
        })
    }

    /** Returns null when the backend is reachable and the token is accepted, else an error message. */
    suspend fun ping(s: Settings): String? = try {
        val req = Request.Builder().url(base(s) + "/v1/ping")
            .header("Authorization", "Bearer ${s.appToken}").build()
        http.newCall(req).await().use { r ->
            when {
                r.isSuccessful -> null
                r.code == 401 -> "Backend reachable, but the app token was rejected."
                else -> "Backend answered HTTP ${r.code}."
            }
        }
    } catch (e: Exception) {
        e.message ?: "Could not reach the backend."
    }

    suspend fun chat(
        s: Settings,
        history: List<ChatTurn>,
        memories: List<String>,
        deviceInfo: String,
    ): AssistantReply {
        val body = JSONObject()
            .put("messages", JSONArray().apply {
                history.forEach { put(JSONObject().put("role", it.role).put("content", it.text)) }
            })
            .put("memories", JSONArray(memories))
            .put("device", deviceInfo)
        val req = Request.Builder().url(base(s) + "/v1/chat")
            .header("Authorization", "Bearer ${s.appToken}")
            .post(body.toString().toRequestBody(jsonType)).build()
        http.newCall(req).await().use { r ->
            val txt = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw IOException("Backend error ${r.code}: ${txt.take(200)}")
            val j = JSONObject(txt)
            val acts = mutableListOf<ActionRequest>()
            val arr = j.optJSONArray("actions") ?: JSONArray()
            for (i in 0 until arr.length()) {
                val a = arr.getJSONObject(i)
                acts += ActionRequest(
                    a.optString("id"), a.optString("name"), a.optJSONObject("args") ?: JSONObject(),
                )
            }
            return AssistantReply(j.optString("text", ""), acts)
        }
    }
}
