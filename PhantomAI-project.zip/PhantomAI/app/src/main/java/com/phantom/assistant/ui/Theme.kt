package com.phantom.assistant.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF07070D)
val Panel = Color(0xFF12121C)
val PanelHi = Color(0xFF1B1B29)
val Purple = Color(0xFF8B5CF6)
val Cyan = Color(0xFF22D3EE)
val TextHi = Color(0xFFE8E8F0)
val TextLo = Color(0xFF9A9AB0)
val Danger = Color(0xFFEF4444)
val Good = Color(0xFF34D399)

@Composable
fun PhantomTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple, secondary = Cyan, background = Bg, surface = Panel,
            onSurface = TextHi, onBackground = TextHi, error = Danger,
            surfaceVariant = PanelHi, onSurfaceVariant = TextLo,
        ),
        content = content,
    )
}
