package com.phantom.assistant.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String, // "user" | "assistant"
    val text: String,
    val ts: Long = System.currentTimeMillis(),
)

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kind: String, // preference | task | fact
    val content: String, // AES-GCM ciphertext (base64) when encrypted = true
    val encrypted: Boolean,
    val ts: Long = System.currentTimeMillis(),
)

@Entity(tableName = "action_log")
data class ActionLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val args: String,
    val ok: Boolean,
    val message: String,
    val ts: Long = System.currentTimeMillis(),
)

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages ORDER BY id ASC")
    fun observeAll(): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages ORDER BY id DESC LIMIT :n")
    suspend fun recent(n: Int): List<MessageEntity>

    @Insert suspend fun insert(m: MessageEntity): Long

    @Query("DELETE FROM messages") suspend fun clear()
}

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories ORDER BY id DESC")
    fun observeAll(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories ORDER BY id DESC")
    suspend fun all(): List<MemoryEntity>

    @Insert suspend fun insert(m: MemoryEntity): Long

    @Query("DELETE FROM memories WHERE id = :id") suspend fun delete(id: Long)

    @Query("DELETE FROM memories") suspend fun clear()
}

@Dao
interface ActionLogDao {
    @Query("SELECT * FROM action_log ORDER BY id DESC LIMIT 300")
    fun observeAll(): Flow<List<ActionLogEntity>>

    @Insert suspend fun insert(e: ActionLogEntity): Long

    @Query("DELETE FROM action_log") suspend fun clear()
}

@Database(
    entities = [MessageEntity::class, MemoryEntity::class, ActionLogEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class PhantomDb : RoomDatabase() {
    abstract fun messages(): MessageDao
    abstract fun memories(): MemoryDao
    abstract fun actionLog(): ActionLogDao

    companion object {
        fun get(ctx: Context): PhantomDb =
            Room.databaseBuilder(ctx.applicationContext, PhantomDb::class.java, "phantom.db").build()
    }
}
