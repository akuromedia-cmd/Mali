package com.phantom.assistant.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.store by preferencesDataStore(name = "phantom_prefs")

data class Settings(
    val backendUrl: String = "",
    val appToken: String = "",
    val silenceMs: Int = 2000,
    val countdownSec: Int = 3,
    val speechRate: Float = 1f,
    val speakReplies: Boolean = true,
    val bargeIn: Boolean = false,
    val sounds: Boolean = true,
    val encryptMemories: Boolean = false,
)

class SettingsRepo(private val ctx: Context) {
    private val kUrl = stringPreferencesKey("backend_url")
    private val kToken = stringPreferencesKey("app_token_enc")
    private val kSilence = intPreferencesKey("silence_ms")
    private val kCountdown = intPreferencesKey("countdown_sec")
    private val kRate = floatPreferencesKey("speech_rate")
    private val kSpeak = booleanPreferencesKey("speak_replies")
    private val kBarge = booleanPreferencesKey("barge_in")
    private val kSounds = booleanPreferencesKey("sounds")
    private val kEnc = booleanPreferencesKey("encrypt_memories")

    val flow: Flow<Settings> = ctx.store.data.map { p ->
        Settings(
            backendUrl = p[kUrl] ?: "",
            appToken = p[kToken]?.takeIf { it.isNotBlank() }
                ?.let { runCatching { Crypto.decrypt(it) }.getOrDefault("") } ?: "",
            silenceMs = p[kSilence] ?: 2000,
            countdownSec = p[kCountdown] ?: 3,
            speechRate = p[kRate] ?: 1f,
            speakReplies = p[kSpeak] ?: true,
            bargeIn = p[kBarge] ?: false,
            sounds = p[kSounds] ?: true,
            encryptMemories = p[kEnc] ?: false,
        )
    }

    suspend fun update(block: (Settings) -> Settings) {
        val n = block(flow.first())
        ctx.store.edit { p ->
            p[kUrl] = n.backendUrl
            p[kToken] = if (n.appToken.isBlank()) "" else Crypto.encrypt(n.appToken)
            p[kSilence] = n.silenceMs
            p[kCountdown] = n.countdownSec
            p[kRate] = n.speechRate
            p[kSpeak] = n.speakReplies
            p[kBarge] = n.bargeIn
            p[kSounds] = n.sounds
            p[kEnc] = n.encryptMemories
        }
    }
}
