package com.phantom.assistant

import android.app.Application
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.phantom.assistant.actions.*
import com.phantom.assistant.data.*
import com.phantom.assistant.net.*
import com.phantom.assistant.voice.Sfx
import com.phantom.assistant.voice.VoiceController
import com.phantom.assistant.voice.VoiceController.Mode
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

enum class Phase { IDLE, LISTENING, THINKING, SPEAKING, EXECUTING }

data class UiState(
    val phase: Phase = Phase.IDLE,
    val partial: String = "",
    val reply: String = "",
    val error: String? = null,
    val pending: String? = null,   // action awaiting confirmation
    val countdown: Int = 0,        // -1 = waiting for confirm, >0 = seconds until it runs
    val connected: Boolean? = null,
    val continuous: Boolean = false,
    val wake: Boolean = false,
)

data class MemoryItem(val id: Long, val kind: String, val text: String, val encrypted: Boolean, val ts: Long)

class PhantomViewModel(app: Application) : AndroidViewModel(app), VoiceController.Callbacks {
    private val core = app as PhantomApp
    private val db = core.db
    private val repo = core.settings
    private val engine = ActionEngine(app)
    private val client = BackendClient()
    private val voice = VoiceController(app, this)

    private val _ui = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _ui.asStateFlow()

    val settings: StateFlow<Settings> = repo.flow.stateIn(viewModelScope, SharingStarted.Eagerly, Settings())
    val messages = db.messages().observeAll().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val actionLog = db.actionLog().observeAll().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val memories: StateFlow<List<MemoryItem>> = db.memories().observeAll()
        .map { list -> list.map { MemoryItem(it.id, it.kind, plain(it), it.encrypted, it.ts) } }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    private var job: Job? = null
    private var pendingDeferred: CompletableDeferred<Boolean>? = null
    @Volatile private var pendingCancelled = false

    init {
        viewModelScope.launch {
            repo.flow.collect { voice.silenceMs = it.silenceMs; voice.speechRate = it.speechRate }
        }
        checkConnection()
    }

    private fun plain(e: MemoryEntity) =
        if (e.encrypted) runCatching { Crypto.decrypt(e.content) }.getOrDefault("[unreadable]") else e.content

    private fun sfx(k: Sfx.Kind) { if (settings.value.sounds) Sfx.play(k) }

    // ---------- Connection ----------
    fun checkConnection() = viewModelScope.launch {
        val s = repo.flow.first()
        _ui.update { it.copy(connected = if (s.backendUrl.isBlank()) null else client.ping(s) == null) }
    }

    suspend fun testConnection(url: String, token: String): String {
        val err = client.ping(Settings(backendUrl = url, appToken = token))
        return err ?: "Connected. Backend and token are OK."
    }

    // ---------- Voice entry points ----------
    fun onMic() {
        when (_ui.value.phase) {
            Phase.IDLE -> startListening()
            Phase.LISTENING -> if (pendingDeferred == null) { voice.stopListening(); _ui.update { it.copy(phase = Phase.IDLE, partial = "") } }
            Phase.SPEAKING -> { voice.stopSpeaking(); startListening() }
            else -> {}
        }
    }

    fun startListening(beep: Boolean = true) {
        if (!voice.available) { showError("Speech recognition isn't available here. Type your command instead."); return }
        if (beep) sfx(Sfx.Kind.LISTEN)
        _ui.update { it.copy(phase = Phase.LISTENING, partial = "", error = null) }
        voice.listen(Mode.COMMAND)
    }

    fun toggleContinuous(on: Boolean) {
        _ui.update { it.copy(continuous = on, wake = if (on) false else it.wake) }
        if (on) { voice.stopListening(); if (_ui.value.phase == Phase.IDLE) startListening() }
        else if (_ui.value.phase == Phase.LISTENING && pendingDeferred == null) { voice.stopListening(); _ui.update { it.copy(phase = Phase.IDLE) } }
    }

    fun toggleWake(on: Boolean) {
        _ui.update { it.copy(wake = on, continuous = if (on) false else it.continuous) }
        if (on && _ui.value.phase == Phase.IDLE) voice.listen(Mode.WAKE) else if (!on) voice.stopListening()
    }

    // ---------- VoiceController callbacks ----------
    override fun onPartial(text: String) { _ui.update { it.copy(partial = text) } }
    override fun onCommand(text: String) { _ui.update { it.copy(partial = "") }; submit(text) }
    override fun onWake(textAfterWake: String) {
        sfx(Sfx.Kind.LISTEN)
        if (textAfterWake.isNotBlank()) submit(textAfterWake) else startListening(beep = false)
    }
    override fun onBargeStop() { voice.stopSpeaking(); cancelCurrent(); finishTurn() }
    override fun onSpeakDone() { if (_ui.value.phase == Phase.SPEAKING) { voice.stopListening(); finishTurn() } }
    override fun onError(message: String, fatal: Boolean) {
        if (pendingDeferred?.isActive == true) return // confirmation is still answerable by buttons
        if (!fatal && _ui.value.continuous) { startListening(beep = false); return }
        sfx(Sfx.Kind.FAIL)
        _ui.update {
            it.copy(phase = Phase.IDLE, error = message, partial = "",
                continuous = if (fatal) false else it.continuous, wake = if (fatal) false else it.wake)
        }
    }

    fun showError(msg: String) { _ui.update { it.copy(error = msg, phase = if (it.phase == Phase.LISTENING) Phase.IDLE else it.phase) } }

    // ---------- Stop controls ----------
    private fun isStopCommand(t: String): Boolean {
        val n = t.lowercase().trim().trimEnd('.', '!')
        return n in setOf("stop", "stop talking", "be quiet", "quiet", "shut up", "cancel", "never mind", "nevermind", "stop it", "phantom stop")
    }

    private fun cancelCurrent() {
        job?.cancel(); job = null
        pendingCancelled = true
        pendingDeferred?.complete(false); pendingDeferred = null
        voice.stopSpeaking()
        voice.stopListening()
        _ui.update { it.copy(pending = null, countdown = 0, partial = "") }
    }

    /** Visible emergency stop: cancels everything and turns off continuous/wake listening. */
    fun emergencyStop() {
        cancelCurrent()
        _ui.update { it.copy(phase = Phase.IDLE, continuous = false, wake = false) }
    }

    fun stopSpeakingOnly() { voice.stopSpeaking(); if (_ui.value.phase == Phase.SPEAKING) { voice.stopListening(); finishTurn() } }

    private fun finishTurn() {
        _ui.update { it.copy(phase = Phase.IDLE, partial = "", pending = null, countdown = 0) }
        val u = _ui.value
        when {
            u.continuous -> viewModelScope.launch {
                delay(400)
                if (_ui.value.phase == Phase.IDLE && _ui.value.continuous) startListening()
            }
            u.wake -> voice.listen(Mode.WAKE)
        }
    }

    // ---------- Confirmation ----------
    fun confirmPending() { pendingDeferred?.complete(true) }
    fun cancelPending() { pendingCancelled = true; pendingDeferred?.complete(false) }

    private fun handleConfirmSpeech(text: String) {
        val n = text.lowercase().trim().trimEnd('.', '!')
        val yes = setOf("yes", "yeah", "yep", "sure", "ok", "okay", "confirm", "do it", "go ahead", "yes please")
        val no = setOf("no", "nope", "cancel", "stop", "don't", "dont", "never mind", "nevermind")
        when {
            n in yes -> confirmPending()
            n in no -> cancelPending()
            else -> voice.listen(Mode.COMMAND)
        }
    }

    private suspend fun askConfirm(desc: String): Boolean {
        val d = CompletableDeferred<Boolean>()
        pendingDeferred = d
        pendingCancelled = false
        _ui.update { it.copy(pending = "$desc?", countdown = -1, phase = Phase.LISTENING) }
        voice.listen(Mode.COMMAND) // allows "yes" / "no" by voice
        val confirmed = try { d.await() } finally { voice.stopListening() }
        if (!confirmed) { clearPending(); return false }
        for (s in settings.value.countdownSec downTo 1) {
            _ui.update { it.copy(countdown = s, phase = Phase.EXECUTING) }
            delay(1000)
            if (pendingCancelled) { clearPending(); return false }
        }
        clearPending()
        return true
    }

    private fun clearPending() {
        pendingDeferred = null
        _ui.update { it.copy(pending = null, countdown = 0) }
    }

    // ---------- Conversation ----------
    fun submit(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        if (pendingDeferred?.isActive == true) { handleConfirmSpeech(text); return }
        if (isStopCommand(text)) { cancelCurrent(); finishTurn(); return }
        val p = _ui.value.phase
        if (p == Phase.THINKING || p == Phase.EXECUTING) return
        voice.stopSpeaking()
        voice.stopListening()
        job = viewModelScope.launch {
            _ui.update { it.copy(phase = Phase.THINKING, reply = "", error = null, partial = "") }
            db.messages().insert(MessageEntity(role = "user", text = text))
            try {
                process()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                fail(e.message ?: "Unknown error")
            }
        }
    }

    private fun fail(msg: String) {
        sfx(Sfx.Kind.FAIL)
        _ui.update { it.copy(phase = Phase.IDLE, error = msg, continuous = false, connected = if (msg.startsWith("Backend error")) it.connected else false) }
        val s = settings.value
        if (s.speakReplies && voice.speak("Sorry, something went wrong.")) _ui.update { it.copy(phase = Phase.SPEAKING) }
    }

    private suspend fun process() {
        val history = db.messages().recent(24).reversed().map { ChatTurn(it.role, it.text) }
        val mems = db.memories().all().take(50).map { plain(it) }
        val reply = client.chat(settings.value, history, mems, deviceInfo())
        _ui.update { it.copy(connected = true) }

        val lines = mutableListOf<String>()
        for (req in reply.actions.take(5)) {
            val parsed = ActionParser.parse(req.name, req.args)
            val action = parsed.getOrNull()
            if (action == null) {
                val m = "Skipped ${req.name}: ${parsed.exceptionOrNull()?.message}"
                log(req.name, req.args.toString(), false, m); lines += m; continue
            }
            lines += runAction(req, action).message
        }

        val shown = buildString {
            if (reply.text.isNotBlank()) append(reply.text.trim())
            if (lines.isNotEmpty()) {
                if (isNotEmpty()) append("\n\n")
                append(lines.joinToString("\n") { "• $it" })
            }
        }.ifBlank { "(no response)" }
        db.messages().insert(MessageEntity(role = "assistant", text = shown))
        _ui.update { it.copy(reply = shown) }

        // Speak only verified outcomes when actions ran, so speech never claims unverified success.
        speakOrFinish(if (lines.isNotEmpty()) lines.joinToString(" ") else reply.text)
    }

    private suspend fun runAction(req: ActionRequest, action: Action): ActionResult {
        if (action.needsConfirm && !askConfirm(action.describe)) {
            val r = ActionResult(false, "Cancelled: ${action.describe}.")
            log(req.name, req.args.toString(), false, r.message)
            return r
        }
        _ui.update { it.copy(phase = Phase.EXECUTING) }
        val res = when (action) {
            is Action.Speak -> ActionResult(true, action.text)
            is Action.SaveMemory -> saveMemory(action.kind, action.content)
            else -> engine.execute(action)
        }
        log(req.name, req.args.toString(), res.ok, res.message)
        sfx(if (res.ok) Sfx.Kind.OK else Sfx.Kind.FAIL)
        return res
    }

    private fun speakOrFinish(text: String) {
        if (settings.value.speakReplies && text.isNotBlank() && voice.speak(text)) {
            _ui.update { it.copy(phase = Phase.SPEAKING) }
            if (settings.value.bargeIn) voice.listen(Mode.BARGE)
        } else finishTurn()
    }

    private fun deviceInfo(): String {
        val now = ZonedDateTime.now()
        return "Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT}), ${Build.MANUFACTURER} ${Build.MODEL}. " +
            "Local time: ${now.format(DateTimeFormatter.ofPattern("EEEE yyyy-MM-dd HH:mm"))} ${now.zone}."
    }

    private suspend fun log(type: String, args: String, ok: Boolean, msg: String) {
        db.actionLog().insert(ActionLogEntity(type = type, args = args.take(300), ok = ok, message = msg.take(400)))
    }

    // ---------- Quick actions (no AI round trip) ----------
    private fun quick(name: String, block: suspend () -> ActionResult) {
        if (_ui.value.phase != Phase.IDLE) return
        viewModelScope.launch {
            _ui.update { it.copy(phase = Phase.EXECUTING, error = null) }
            val r = block()
            log(name, "{}", r.ok, r.message)
            sfx(if (r.ok) Sfx.Kind.OK else Sfx.Kind.FAIL)
            _ui.update { it.copy(phase = Phase.IDLE, reply = r.message) }
        }
    }
    fun quickFlashlight() = quick("TOGGLE_FLASHLIGHT") { engine.execute(Action.Flashlight(null)) }
    fun quickSettings() = quick("OPEN_SYSTEM_SETTINGS") { engine.execute(Action.OpenSettings("main")) }
    fun quickAlarms() = quick("SHOW_ALARMS") { runCatching { engine.showAlarms() }.fold({ ActionResult(true, "Opened your alarms.") }, { ActionResult(false, "No clock app handled that.") }) }
    fun launchApp(info: AppInfo) = quick("OPEN_APP") { engine.launchPackage(info) }
    fun listApps() = engine.listApps()

    // ---------- Memory ----------
    private val sensitive = Regex(
        "(?i)(password|passcode|passwd|\\botp\\b|one[- ]time|verification code|\\bcvv\\b|\\bpin\\b|secret key|api key)|\\b\\d{6}\\b|\\b(?:\\d[ -]?){13,19}\\b",
    )

    suspend fun saveMemory(kind: String, content: String): ActionResult {
        if (sensitive.containsMatchIn(content))
            return ActionResult(false, "I won't store that. It looks like a password, code, or card number.")
        val enc = settings.value.encryptMemories
        db.memories().insert(MemoryEntity(kind = kind, content = if (enc) Crypto.encrypt(content) else content, encrypted = enc))
        return ActionResult(true, "Saved to memory: $content")
    }

    fun addMemory(text: String, onResult: (String) -> Unit) = viewModelScope.launch {
        onResult(saveMemory("fact", text.trim().take(300)).message)
    }
    fun forget(id: Long) = viewModelScope.launch { db.memories().delete(id) }
    fun clearMemories() = viewModelScope.launch { db.memories().clear() }
    fun clearHistory() = viewModelScope.launch { db.messages().clear(); _ui.update { it.copy(reply = "") } }
    fun clearActionLog() = viewModelScope.launch { db.actionLog().clear() }
    fun wipeAll() = viewModelScope.launch { db.messages().clear(); db.memories().clear(); db.actionLog().clear(); _ui.update { it.copy(reply = "") } }

    fun updateSettings(block: (Settings) -> Settings) = viewModelScope.launch { repo.update(block) }

    override fun onCleared() { voice.release(); super.onCleared() }
}
